
{
    'name': 'Sale Order Stock Picking Lines',
    'version': '1.0.5',
    'sequence':1,
    'category': '',
    'description': """
        App will print ABC Analysis Report.
    """,
    'author': 'Dexciss Technology Pvt. Ltd. (Sangita)',
    'summary': 'App will print ABC Analysis Report.',
    'website': 'http://www.dexciss.com/',
    'images': [],
    'depends': ['stock'],
    'data': [
            'view/sale_order_picking_operation_line.xml',
            ],
                        
    'installable': True,
    'application': True,
    'auto_install': False,
}

